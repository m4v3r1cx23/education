﻿using Numbers;

var numberSorter = new NumberSorter();

numberSorter.read_data();
numberSorter.process_data();
numberSorter.show_results();