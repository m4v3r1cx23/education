﻿using RectangleArea;

var rectangle = new Rectangle();

rectangle.read_data();
rectangle.process_data();
rectangle.show_results();